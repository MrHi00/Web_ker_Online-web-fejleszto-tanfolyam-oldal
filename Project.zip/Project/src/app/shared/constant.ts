export const ProfileObject = [
    {
      'id': '123farf',
      'user_name': 'Billy',
      'user_url': '',
      'photo_url': '',
      'email': '',
      'avatar': 'J',
      'tasks': {
        'total': 10,
        'completed': 8,
        'pending': 2
      }
    }
];