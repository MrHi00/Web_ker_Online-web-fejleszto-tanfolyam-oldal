export interface Task {
    id: number;
    name: string;
    completed: boolean;
    licencePeriod: Date;
    description?: string;
  }